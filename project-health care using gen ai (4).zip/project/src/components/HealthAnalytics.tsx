import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Heart, Activity, Calendar, Target } from 'lucide-react';

interface HealthMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  status: 'normal' | 'warning' | 'critical';
  target?: number;
}

interface ChartData {
  date: string;
  heartRate: number;
  bloodPressureSys: number;
  bloodPressureDia: number;
  glucose: number;
  weight: number;
}

const HealthAnalytics: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState('heartRate');
  const [timeRange, setTimeRange] = useState('7d');
  const [chartData, setChartData] = useState<ChartData[]>([]);

  // Generate mock data
  useEffect(() => {
    const generateMockData = (): ChartData[] => {
      const data: ChartData[] = [];
      const today = new Date();
      
      for (let i = 29; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        
        data.push({
          date: date.toISOString().split('T')[0],
          heartRate: 65 + Math.random() * 20,
          bloodPressureSys: 115 + Math.random() * 25,
          bloodPressureDia: 75 + Math.random() * 15,
          glucose: 85 + Math.random() * 30,
          weight: 70 + Math.random() * 5
        });
      }
      
      return data;
    };

    setChartData(generateMockData());
  }, []);

  const healthMetrics: HealthMetric[] = [
    {
      id: 'heartRate',
      name: 'Heart Rate',
      value: 72,
      unit: 'bpm',
      trend: 'stable',
      status: 'normal',
      target: 70
    },
    {
      id: 'bloodPressure',
      name: 'Blood Pressure',
      value: 120,
      unit: 'mmHg',
      trend: 'down',
      status: 'normal',
      target: 120
    },
    {
      id: 'glucose',
      name: 'Blood Glucose',
      value: 95,
      unit: 'mg/dL',
      trend: 'up',
      status: 'normal',
      target: 100
    },
    {
      id: 'weight',
      name: 'Weight',
      value: 72.5,
      unit: 'kg',
      trend: 'down',
      status: 'normal',
      target: 70
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'text-green-600 bg-green-50 border-green-200';
      case 'warning': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return '↗️';
      case 'down': return '↘️';
      case 'stable': return '→';
      default: return '→';
    }
  };

  const SimpleChart: React.FC<{ data: ChartData[], metric: string }> = ({ data, metric }) => {
    const values = data.map(d => {
      switch (metric) {
        case 'heartRate': return d.heartRate;
        case 'bloodPressureSys': return d.bloodPressureSys;
        case 'glucose': return d.glucose;
        case 'weight': return d.weight;
        default: return d.heartRate;
      }
    });

    const max = Math.max(...values);
    const min = Math.min(...values);
    const range = max - min;

    return (
      <div className="relative h-64 bg-gradient-to-b from-blue-50 to-transparent rounded-lg p-4">
        <svg className="w-full h-full" viewBox="0 0 400 200">
          {/* Grid lines */}
          {[0, 1, 2, 3, 4].map(i => (
            <line
              key={i}
              x1="0"
              y1={i * 40}
              x2="400"
              y2={i * 40}
              stroke="#e5e7eb"
              strokeWidth="1"
            />
          ))}
          
          {/* Chart line */}
          <polyline
            fill="none"
            stroke="url(#gradient)"
            strokeWidth="3"
            points={values.map((value, index) => {
              const x = (index / (values.length - 1)) * 400;
              const y = 200 - ((value - min) / range) * 160 - 20;
              return `${x},${y}`;
            }).join(' ')}
          />
          
          {/* Data points */}
          {values.map((value, index) => {
            const x = (index / (values.length - 1)) * 400;
            const y = 200 - ((value - min) / range) * 160 - 20;
            return (
              <circle
                key={index}
                cx={x}
                cy={y}
                r="4"
                fill="#3b82f6"
                className="hover:r-6 transition-all cursor-pointer"
              />
            );
          })}
          
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Health Metrics Overview */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Health Analytics Dashboard</h2>
            <p className="text-gray-600">Track your vital signs and health metrics</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {healthMetrics.map((metric) => (
            <div key={metric.id} className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-5 border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  {metric.id === 'heartRate' && <Heart className="w-5 h-5 text-red-500" />}
                  {metric.id === 'bloodPressure' && <Activity className="w-5 h-5 text-blue-500" />}
                  {metric.id === 'glucose' && <TrendingUp className="w-5 h-5 text-green-500" />}
                  {metric.id === 'weight' && <Target className="w-5 h-5 text-purple-500" />}
                  <h3 className="font-medium text-gray-900">{metric.name}</h3>
                </div>
                <span className="text-lg">{getTrendIcon(metric.trend)}</span>
              </div>
              
              <div className="mb-3">
                <div className="flex items-baseline space-x-1">
                  <span className="text-2xl font-bold text-gray-900">{metric.value}</span>
                  <span className="text-sm text-gray-500">{metric.unit}</span>
                </div>
                {metric.target && (
                  <p className="text-xs text-gray-500 mt-1">
                    Target: {metric.target} {metric.unit}
                  </p>
                )}
              </div>
              
              <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(metric.status)}`}>
                {metric.status.charAt(0).toUpperCase() + metric.status.slice(1)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Charts Section */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Trends & History</h3>
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            <select
              value={selectedMetric}
              onChange={(e) => setSelectedMetric(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="heartRate">Heart Rate</option>
              <option value="bloodPressureSys">Blood Pressure</option>
              <option value="glucose">Blood Glucose</option>
              <option value="weight">Weight</option>
            </select>
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 3 months</option>
            </select>
          </div>
        </div>

        <SimpleChart data={chartData} metric={selectedMetric} />
      </div>

      {/* Health Insights */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <TrendingUp className="w-5 h-5 mr-2 text-blue-600" />
          AI Health Insights
        </h3>
        
        <div className="space-y-4">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-medium text-green-800">Positive Trend</h4>
                <p className="text-green-700 text-sm mt-1">
                  Your heart rate has been consistently within the healthy range over the past week. 
                  Keep up the good work with your current exercise routine!
                </p>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-medium text-blue-800">Recommendation</h4>
                <p className="text-blue-700 text-sm mt-1">
                  Consider increasing your daily water intake. Proper hydration can help maintain 
                  optimal blood pressure levels and overall cardiovascular health.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-medium text-purple-800">Goal Achievement</h4>
                <p className="text-purple-700 text-sm mt-1">
                  You're making great progress toward your weight goal. You're currently 2.5kg from 
                  your target weight of 70kg. Consider maintaining your current diet and exercise plan.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Next Check-up */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">Stay on Top of Your Health</h3>
            <p className="text-blue-100">
              Regular check-ups help catch potential issues early and keep you on track with your health goals.
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Calendar className="w-8 h-8 text-blue-200" />
            <button className="bg-white text-blue-600 px-6 py-3 rounded-xl font-medium hover:bg-blue-50 transition-colors">
              Schedule Check-up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthAnalytics;
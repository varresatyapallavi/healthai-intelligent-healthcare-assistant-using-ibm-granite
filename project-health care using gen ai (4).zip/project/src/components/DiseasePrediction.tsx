import React, { useState } from 'react';
import { Search, AlertTriangle, CheckCircle, Info, TrendingUp } from 'lucide-react';

interface Symptom {
  id: string;
  name: string;
  severity: 'mild' | 'moderate' | 'severe';
}

interface Prediction {
  condition: string;
  probability: number;
  description: string;
  urgency: 'low' | 'medium' | 'high';
  recommendations: string[];
}

const DiseasePrediction: React.FC = () => {
  const [selectedSymptoms, setSelectedSymptoms] = useState<Symptom[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const commonSymptoms = [
    'Headache', 'Fever', 'Cough', 'Sore throat', 'Fatigue', 'Nausea',
    'Chest pain', 'Shortness of breath', 'Dizziness', 'Abdominal pain',
    'Joint pain', 'Muscle aches', 'Skin rash', 'Loss of appetite'
  ];

  const filteredSymptoms = commonSymptoms.filter(symptom =>
    symptom.toLowerCase().includes(searchTerm.toLowerCase()) &&
    !selectedSymptoms.some(s => s.name === symptom)
  );

  const addSymptom = (symptomName: string) => {
    const newSymptom: Symptom = {
      id: Date.now().toString(),
      name: symptomName,
      severity: 'mild'
    };
    setSelectedSymptoms([...selectedSymptoms, newSymptom]);
    setSearchTerm('');
  };

  const removeSymptom = (id: string) => {
    setSelectedSymptoms(selectedSymptoms.filter(s => s.id !== id));
  };

  const updateSeverity = (id: string, severity: 'mild' | 'moderate' | 'severe') => {
    setSelectedSymptoms(selectedSymptoms.map(s => 
      s.id === id ? { ...s, severity } : s
    ));
  };

  const generatePredictions = (): Prediction[] => {
    const mockPredictions: Prediction[] = [
      {
        condition: 'Common Cold',
        probability: 85,
        description: 'A viral infection of the upper respiratory tract',
        urgency: 'low',
        recommendations: [
          'Get plenty of rest',
          'Stay hydrated',
          'Use throat lozenges for sore throat',
          'Consider over-the-counter pain relievers'
        ]
      },
      {
        condition: 'Seasonal Allergies',
        probability: 65,
        description: 'Allergic reaction to environmental allergens',
        urgency: 'low',
        recommendations: [
          'Avoid known allergens',
          'Consider antihistamines',
          'Keep windows closed during high pollen days',
          'Shower after outdoor activities'
        ]
      },
      {
        condition: 'Viral Gastroenteritis',
        probability: 45,
        description: 'Stomach flu caused by viral infection',
        urgency: 'medium',
        recommendations: [
          'Stay hydrated with clear fluids',
          'Follow BRAT diet (Bananas, Rice, Applesauce, Toast)',
          'Rest and avoid dairy products',
          'Seek medical attention if symptoms worsen'
        ]
      }
    ];

    return mockPredictions.sort((a, b) => b.probability - a.probability);
  };

  const analyzeSynptoms = async () => {
    if (selectedSymptoms.length === 0) return;

    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      setPredictions(generatePredictions());
      setIsAnalyzing(false);
    }, 2000);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'severe': return 'bg-red-100 text-red-800 border-red-200';
      case 'moderate': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'mild': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-8">
      {/* Symptom Input Section */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
            <Search className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Symptom Analysis</h2>
            <p className="text-gray-600">Add your symptoms to get AI-powered health insights</p>
          </div>
        </div>

        {/* Symptom Search */}
        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for symptoms..."
              className="w-full px-4 py-3 pl-10 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
            <Search className="absolute left-3 top-3.5 w-4 h-4 text-gray-400" />
          </div>
          
          {searchTerm && filteredSymptoms.length > 0 && (
            <div className="mt-2 bg-white border border-gray-200 rounded-lg shadow-sm">
              {filteredSymptoms.slice(0, 5).map((symptom) => (
                <button
                  key={symptom}
                  onClick={() => addSymptom(symptom)}
                  className="w-full px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg transition-colors"
                >
                  {symptom}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Selected Symptoms */}
        {selectedSymptoms.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Selected Symptoms</h3>
            <div className="space-y-3">
              {selectedSymptoms.map((symptom) => (
                <div key={symptom.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium text-gray-900">{symptom.name}</span>
                  <div className="flex items-center space-x-3">
                    <select
                      value={symptom.severity}
                      onChange={(e) => updateSeverity(symptom.id, e.target.value as any)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border ${getSeverityColor(symptom.severity)}`}
                    >
                      <option value="mild">Mild</option>
                      <option value="moderate">Moderate</option>
                      <option value="severe">Severe</option>
                    </select>
                    <button
                      onClick={() => removeSymptom(symptom.id)}
                      className="text-red-500 hover:text-red-700 transition-colors"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Analyze Button */}
        <button
          onClick={analyzeSynptoms}
          disabled={selectedSymptoms.length === 0 || isAnalyzing}
          className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white py-3 px-6 rounded-xl font-medium hover:from-green-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105"
        >
          {isAnalyzing ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Analyzing Symptoms...
            </div>
          ) : (
            `Analyze ${selectedSymptoms.length} Symptom${selectedSymptoms.length !== 1 ? 's' : ''}`
          )}
        </button>
      </div>

      {/* Results Section */}
      {predictions.length > 0 && (
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Potential Conditions</h2>
              <p className="text-gray-600">Based on AI analysis of your symptoms</p>
            </div>
          </div>

          <div className="space-y-4">
            {predictions.map((prediction, index) => (
              <div key={index} className="border border-gray-200 rounded-xl p-5 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-900">{prediction.condition}</h3>
                  <div className="flex items-center space-x-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getUrgencyColor(prediction.urgency)}`}>
                      {prediction.urgency.toUpperCase()} PRIORITY
                    </span>
                    <span className="text-2xl font-bold text-blue-600">{prediction.probability}%</span>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-4">{prediction.description}</p>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Recommendations
                  </h4>
                  <ul className="space-y-1">
                    {prediction.recommendations.map((rec, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-start">
                        <span className="w-1.5 h-1.5 bg-blue-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-amber-800">Important Disclaimer</h4>
                <p className="text-sm text-amber-700 mt-1">
                  This AI analysis is for informational purposes only and should not replace professional medical advice. 
                  Please consult with a healthcare provider for accurate diagnosis and treatment.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiseasePrediction;
import React, { useState } from 'react';
import { FileText, Calendar, Clock, Pill, Activity, AlertCircle, CheckSquare } from 'lucide-react';

interface TreatmentPlan {
  id: string;
  condition: string;
  duration: string;
  medications: Medication[];
  lifestyle: LifestyleRecommendation[];
  followUp: FollowUp[];
  warnings: string[];
}

interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
}

interface LifestyleRecommendation {
  category: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
}

interface FollowUp {
  type: string;
  timeframe: string;
  description: string;
}

const TreatmentPlan: React.FC = () => {
  const [selectedCondition, setSelectedCondition] = useState('');
  const [patientInfo, setPatientInfo] = useState({
    age: '',
    weight: '',
    allergies: '',
    currentMedications: ''
  });
  const [treatmentPlan, setTreatmentPlan] = useState<TreatmentPlan | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const commonConditions = [
    'Hypertension',
    'Type 2 Diabetes',
    'Common Cold',
    'Migraine',
    'Anxiety',
    'Upper Respiratory Infection',
    'Gastroesophageal Reflux Disease',
    'Seasonal Allergies'
  ];

  const generateTreatmentPlan = (): TreatmentPlan => {
    const mockPlans: { [key: string]: TreatmentPlan } = {
      'Hypertension': {
        id: '1',
        condition: 'Hypertension',
        duration: '12 weeks initial treatment',
        medications: [
          {
            name: 'Lisinopril',
            dosage: '10mg',
            frequency: 'Once daily',
            duration: 'Ongoing',
            instructions: 'Take in the morning with or without food'
          },
          {
            name: 'Hydrochlorothiazide',
            dosage: '25mg',
            frequency: 'Once daily',
            duration: 'Ongoing',
            instructions: 'Take in the morning to avoid nighttime urination'
          }
        ],
        lifestyle: [
          {
            category: 'Diet',
            description: 'Follow DASH diet - reduce sodium intake to <2300mg daily',
            priority: 'high'
          },
          {
            category: 'Exercise',
            description: 'Moderate aerobic exercise 150 minutes per week',
            priority: 'high'
          },
          {
            category: 'Monitoring',
            description: 'Daily blood pressure monitoring at home',
            priority: 'medium'
          }
        ],
        followUp: [
          {
            type: 'Blood Pressure Check',
            timeframe: '2 weeks',
            description: 'Monitor medication effectiveness and side effects'
          },
          {
            type: 'Comprehensive Review',
            timeframe: '3 months',
            description: 'Assess overall treatment response and adjust plan'
          }
        ],
        warnings: [
          'Monitor for dizziness, especially when standing up',
          'Report persistent dry cough to healthcare provider',
          'Avoid sudden discontinuation of medications'
        ]
      },
      'Common Cold': {
        id: '2',
        condition: 'Common Cold',
        duration: '7-10 days',
        medications: [
          {
            name: 'Acetaminophen',
            dosage: '500mg',
            frequency: 'Every 6 hours as needed',
            duration: '7 days',
            instructions: 'Take with food to reduce stomach irritation'
          },
          {
            name: 'Dextromethorphan',
            dosage: '15mg',
            frequency: 'Every 4 hours as needed',
            duration: '5 days',
            instructions: 'For dry cough only'
          }
        ],
        lifestyle: [
          {
            category: 'Rest',
            description: 'Get adequate sleep (8-9 hours) to support immune system',
            priority: 'high'
          },
          {
            category: 'Hydration',
            description: 'Increase fluid intake - water, herbal teas, warm broths',
            priority: 'high'
          },
          {
            category: 'Nutrition',
            description: 'Eat light, nutritious meals rich in vitamin C',
            priority: 'medium'
          }
        ],
        followUp: [
          {
            type: 'Self-monitoring',
            timeframe: '3-5 days',
            description: 'If symptoms worsen or fever exceeds 101°F, seek medical care'
          }
        ],
        warnings: [
          'Seek immediate care if difficulty breathing occurs',
          'Do not exceed recommended medication dosages',
          'Avoid contact with others to prevent spread'
        ]
      }
    };

    return mockPlans[selectedCondition] || mockPlans['Common Cold'];
  };

  const handleGeneratePlan = async () => {
    if (!selectedCondition) return;
    
    setIsGenerating(true);
    
    // Simulate AI processing
    setTimeout(() => {
      setTreatmentPlan(generateTreatmentPlan());
      setIsGenerating(false);
    }, 2000);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-8">
      {/* Input Section */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Treatment Plan Generator</h2>
            <p className="text-gray-600">Get personalized treatment recommendations</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Condition Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Medical Condition
            </label>
            <select
              value={selectedCondition}
              onChange={(e) => setSelectedCondition(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="">Select a condition</option>
              {commonConditions.map((condition) => (
                <option key={condition} value={condition}>
                  {condition}
                </option>
              ))}
            </select>
          </div>

          {/* Patient Info */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Age
              </label>
              <input
                type="number"
                value={patientInfo.age}
                onChange={(e) => setPatientInfo({...patientInfo, age: e.target.value})}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter age"
              />
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Known Allergies
            </label>
            <textarea
              value={patientInfo.allergies}
              onChange={(e) => setPatientInfo({...patientInfo, allergies: e.target.value})}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              rows={3}
              placeholder="List any known allergies..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Current Medications
            </label>
            <textarea
              value={patientInfo.currentMedications}
              onChange={(e) => setPatientInfo({...patientInfo, currentMedications: e.target.value})}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              rows={3}
              placeholder="List current medications..."
            />
          </div>
        </div>

        <button
          onClick={handleGeneratePlan}
          disabled={!selectedCondition || isGenerating}
          className="w-full mt-6 bg-gradient-to-r from-purple-500 to-blue-500 text-white py-3 px-6 rounded-xl font-medium hover:from-purple-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105"
        >
          {isGenerating ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Generating Treatment Plan...
            </div>
          ) : (
            'Generate Treatment Plan'
          )}
        </button>
      </div>

      {/* Treatment Plan Results */}
      {treatmentPlan && (
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{treatmentPlan.condition} Treatment Plan</h2>
              <p className="text-gray-600 flex items-center mt-1">
                <Clock className="w-4 h-4 mr-2" />
                Duration: {treatmentPlan.duration}
              </p>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Download PDF
            </button>
          </div>

          {/* Medications */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Pill className="w-5 h-5 mr-2 text-blue-600" />
              Medications
            </h3>
            <div className="space-y-4">
              {treatmentPlan.medications.map((med, index) => (
                <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-gray-900">{med.name}</h4>
                    <span className="text-sm text-blue-600 font-medium">{med.dosage}</span>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
                    <div>
                      <span className="font-medium">Frequency:</span> {med.frequency}
                    </div>
                    <div>
                      <span className="font-medium">Duration:</span> {med.duration}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    <span className="font-medium">Instructions:</span> {med.instructions}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Lifestyle Recommendations */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Activity className="w-5 h-5 mr-2 text-green-600" />
              Lifestyle Recommendations
            </h3>
            <div className="space-y-3">
              {treatmentPlan.lifestyle.map((rec, index) => (
                <div key={index} className="flex items-start space-x-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <CheckSquare className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-semibold text-gray-900">{rec.category}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(rec.priority)}`}>
                        {rec.priority.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-gray-600">{rec.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Follow-up Schedule */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-purple-600" />
              Follow-up Schedule
            </h3>
            <div className="space-y-3">
              {treatmentPlan.followUp.map((followUp, index) => (
                <div key={index} className="flex items-start space-x-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                  <Calendar className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-semibold text-gray-900">{followUp.type}</h4>
                      <span className="text-sm text-purple-600 font-medium">in {followUp.timeframe}</span>
                    </div>
                    <p className="text-gray-600">{followUp.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Warnings */}
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-red-800 mb-3 flex items-center">
              <AlertCircle className="w-5 h-5 mr-2" />
              Important Warnings & Precautions
            </h3>
            <ul className="space-y-2">
              {treatmentPlan.warnings.map((warning, index) => (
                <li key={index} className="text-red-700 flex items-start">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                  {warning}
                </li>
              ))}
            </ul>
          </div>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-amber-800">Medical Disclaimer</h4>
                <p className="text-sm text-amber-700 mt-1">
                  This treatment plan is AI-generated and for informational purposes only. Always consult with qualified healthcare 
                  professionals before starting any treatment. Individual responses to treatment may vary.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TreatmentPlan;
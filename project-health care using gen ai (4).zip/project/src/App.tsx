import React, { useState } from 'react';
import { 
  MessageCircle, 
  Activity, 
  FileText, 
  BarChart3, 
  Send, 
  User, 
  Bot,
  Heart,
  Brain,
  Shield,
  TrendingUp,
  Calendar,
  Clock
} from 'lucide-react';
import PatientChat from './components/PatientChat';
import DiseasePrediction from './components/DiseasePrediction';
import TreatmentPlan from './components/TreatmentPlan';
import HealthAnalytics from './components/HealthAnalytics';

type TabType = 'chat' | 'prediction' | 'treatment' | 'analytics';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('chat');

  const tabs = [
    { id: 'chat', label: 'Patient Chat', icon: MessageCircle, color: 'text-blue-600' },
    { id: 'prediction', label: 'Disease Prediction', icon: Activity, color: 'text-green-600' },
    { id: 'treatment', label: 'Treatment Plan', icon: FileText, color: 'text-purple-600' },
    { id: 'analytics', label: 'Health Analytics', icon: BarChart3, color: 'text-orange-600' },
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'chat':
        return <PatientChat />;
      case 'prediction':
        return <DiseasePrediction />;
      case 'treatment':
        return <TreatmentPlan />;
      case 'analytics':
        return <HealthAnalytics />;
      default:
        return <PatientChat />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                  HealthAI
                </h1>
                <p className="text-sm text-gray-500">AI-Powered Healthcare Assistant</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Shield className="w-4 h-4 text-green-500" />
                <span>Secure & Private</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-1 bg-white p-1 rounded-xl shadow-sm border border-gray-100">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-md transform scale-105'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Main Content */}
        <div className="transition-all duration-300 ease-in-out">
          {renderActiveComponent()}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Brain className="w-5 h-5 text-blue-600" />
              <span className="text-gray-600">Powered by Advanced AI Technology</span>
            </div>
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <span>© 2024 HealthAI</span>
              <span>•</span>
              <span>HIPAA Compliant</span>
              <span>•</span>
              <span>24/7 Support</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;